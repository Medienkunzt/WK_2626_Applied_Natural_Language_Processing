# WK_2626_Applied_Natural_Language_Processing
Dieser Code wurde von Johannes Kunz und Jonas Wölfer in zusammenarbeit erstellt.